//*Algoritmo 1 Hola Mundo*
using System;

class Programa
{
    static void Main()
    {
        Console.WriteLine("¡Hola, mundo!");
    }
}
